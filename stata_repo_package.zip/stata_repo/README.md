# 📊 Stata Analysis Template

This repository contains a template folder and script structure for executing a Stata-based data analysis project.

## 🗂 Structure

- `02_Codes/` — All `.do` files (scripts) for import, cleaning, analysis, tables
- `03_Data/` — Raw and cleaned datasets
- `06_Output/` — Results, tables, graphs

## ▶ How to Run

1. Open Stata
2. Run the `main.do` script from the root directory:
   ```stata
   do 02_Codes/main.do
   ```

This will automatically run import, cleaning, analysis, and table generation steps in order.

---

Created by **Md. Zahirul Islam**  
📧 zahirul.islam.spa@gmail.com  
📱 +8801711792629
